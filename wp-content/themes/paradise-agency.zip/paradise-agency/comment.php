<?php
/**
 * Created by PhpStorm.
 * User: frank
 * Date: 28/04/2017
 * Time: 04:14 PM
 */?>
<div class="well">
    <h4>Leave a Comment:</h4>
    <form role="form">
        <div class="form-group">
            <textarea class="form-control" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
