<?php get_header()?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <?php

            if (have_posts()) :
                while (have_posts()) : the_post();?>

                    <div class="col-lg-8">

                        <!-- Blog Post -->

                        <!-- Title -->
                        <h1><?php the_title()?></h1>

                        <!-- Author -->
                        <p class="lead">
                            by <a href="#"><?php the_author()?></a>
                        </p>

                        <hr>

                        <!-- Date/Time -->
                        <p><span class="glyphicon glyphicon-time"></span> <?php the_time('F j, Y g:i a'); ?></p>

                        <hr>

                        <!-- Preview Image -->
                        <img class="img-responsive" src="<?php the_post_thumbnail_url()?>" alt="">

                        <hr>

                        <!-- Post Content -->
                        <p class="lead"> <?php echo get_the_content()?></p>

                        <hr>

                        <!-- Blog Comments -->
                        <?php comments_template()?>

                        <!-- Comments Form -->


                        <hr>

                        <!-- Posted Comments -->

                        <!-- Comment -->


                        <!-- Comment -->


                    </div>


                <?php endwhile;

            else :
                echo '<p>No content found</p>';

            endif;

            ?>

            <!-- Blog Post Content Column -->


            <!-- Blog Sidebar Widgets Column -->
            <div class="col-md-4">

                <!-- Blog Search Well -->
                <div class="well">
                    <h4>Blog Search</h4>
                    <div class="input-group">
                        <input type="text" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button">
                                <span class="glyphicon glyphicon-search"></span>
                        </button>
                        </span>
                    </div>
                    <!-- /.input-group -->
                </div>

                <!-- Blog Categories Well -->
                <div class="well">
                    <h4>Blog Categories</h4>
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-unstyled">
                                <li><a href="#">Category Name</a>
                                </li>
                                <li><a href="#">Category Name</a>
                                </li>
                                <li><a href="#">Category Name</a>
                                </li>
                                <li><a href="#">Category Name</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <ul class="list-unstyled">
                                <li><a href="#">Category Name</a>
                                </li>
                                <li><a href="#">Category Name</a>
                                </li>
                                <li><a href="#">Category Name</a>
                                </li>
                                <li><a href="#">Category Name</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>

                <!-- Side Widget Well -->
                <div class="well">
                    <h4>Side Widget Well</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>
                </div>

            </div>

        </div>
        <!-- /.row -->

        <hr>
        <?php get_footer() ?>


