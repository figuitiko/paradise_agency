<?php
/**
 * Created by PhpStorm.
 * User: frank
 * Date: 28/04/2017
 * Time: 02:17 PM
 */?>


<div class="row">
    <div class="col-md-7">
        <a href="#">
            <img  src="<?php the_post_thumbnail_url()?>" alt="" height="400" width="600">
        </a>
    </div>
    <div class="col-md-5">
        <h3><?php the_title()?></h3>

        <p><?php the_excerpt()?></p>
        <a class="btn btn-primary" href="<?php the_permalink()?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>
    </div>
    <div class="col-lg-12">
    <hr>
    </div>
</div>