<div style="margin-top:45px;"></div>
<div class='clear'>
  <small class="muted">
    <?php echo sprintf(__('%sShareaholic for WordPress v'. ShareaholicUtilities::get_version() .'%s | %sPrivacy Policy%s | %sTerms of Service%s | %sSupport Center%s | %sAPI%s | %sSocial Analytics%s', 'shareaholic'), '<a href="https://shareaholic.com/?src=wp_admin" target="_new">', '</a>', '<a href="https://shareaholic.com/privacy/?src=wp_admin" target="_new">', '</a>', '<a href="https://shareaholic.com/terms/?src=wp_admin" target="_new">', '</a>', '<a href="http://support.shareaholic.com/" target="_new">', '</a>', '<a href="https://shareaholic.com/api/?src=wp_admin" target="_new">', '</a>', '<a href="https://shareaholic.com/publishers/analytics/'. ShareaholicUtilities::get_host() .'/30?src=wp_admin" target="_new">', '</a>'); ?>
  </small>
  <br />
  <small class="muted">
    <?php echo sprintf(__('If you like our work, show some love and %sgive us a good rating%s. Made with much love in Boston, Massachusetts.', 'shareaholic'), '<a href="http://wordpress.org/support/view/plugin-reviews/shareaholic?rate=5#postform" target="_new">', '</a>'); ?>
  </small>
  <br />
  <br />
  <iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fshareaholic&amp;width&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;share=false&amp;height=80&amp;width=500&amp;appId=207766518608" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:500px; height:80px;" allowTransparency="true"></iframe>
</div>

<!-- Start of Async HubSpot Analytics -->
<script type="text/javascript">
var _hsq = _hsq || [];
_hsq.push(["setContentType", "standard-page"]);
	(function(d,s,i,r) {
	if (d.getElementById(i)){return;}
	var n = d.createElement(s),e = document.getElementsByTagName(s)[0];
	n.id=i;n.src = '//js.hubspot.com/analytics/'+(Math.ceil(new Date()/r)*r)+'/210895.js';
	e.parentNode.insertBefore(n, e);
	})(document, "script", "hs-analytics",300000);
</script>
<!-- End of Async HubSpot Analytics Code -->